import java.util.ArrayList;
import java.util.List;

public class Moves {
	
	public static State applyMove(State state, String move){
        String[] faces = state.numbers;
        String[] newFaces = faces.clone();
        if(move== "F"){
            newFaces[0] = faces[0];
            newFaces[1] = faces[1];
            newFaces[2] = faces[19];
            newFaces[3] = faces[17];
            newFaces[4] = faces[2];
            newFaces[5] = faces[5];
            newFaces[6] = faces[3];
            newFaces[7] = faces[7];
            newFaces[8] = faces[10];
            newFaces[9] = faces[8];
            newFaces[10] = faces[11];
            newFaces[11] = faces[9];
            newFaces[12] = faces[6];
            newFaces[13] = faces[4];
            newFaces[14] = faces[14];
            newFaces[15] = faces[15];
            newFaces[16] = faces[16];
            newFaces[17] = faces[12];
            newFaces[18] = faces[18];
            newFaces[19] = faces[13];
            newFaces[20] = faces[20];
            newFaces[21] = faces[21];
            newFaces[22] = faces[22];
            newFaces[23] = faces[23];
        }
        else if (move=="F'"){
            newFaces[0] = faces[0];
            newFaces[1] = faces[1];
            newFaces[2] = faces[4];
            newFaces[3] = faces[6];
            newFaces[4] = faces[13];
            newFaces[5] = faces[5];
            newFaces[6] = faces[12];
            newFaces[7] = faces[7];
            newFaces[8] = faces[9];
            newFaces[9] = faces[11];
            newFaces[10] = faces[8];
            newFaces[11] = faces[10];
            newFaces[12] = faces[17];
            newFaces[13] = faces[19];
            newFaces[14] = faces[14];
            newFaces[15] = faces[15];
            newFaces[16] = faces[16];
            newFaces[17] = faces[3];
            newFaces[18] = faces[18];
            newFaces[19] = faces[2];
            newFaces[20] = faces[20];
            newFaces[21] = faces[21];
            newFaces[22] = faces[22];
            newFaces[23] = faces[23];
        }
        else if (move=="R"){
            newFaces[0] = faces[0];
            newFaces[1] = faces[9];
            newFaces[2] = faces[2];
            newFaces[3] = faces[11];
            newFaces[4] = faces[6];
            newFaces[5] = faces[4];
            newFaces[6] = faces[7];
            newFaces[7] = faces[5];
            newFaces[8] = faces[8];
            newFaces[9] = faces[13];
            newFaces[10] = faces[10];
            newFaces[11] = faces[15];
            newFaces[12] = faces[12];
            newFaces[13] = faces[22];
            newFaces[14] = faces[14];
            newFaces[15] = faces[20];
            newFaces[16] = faces[16];
            newFaces[17] = faces[17];
            newFaces[18] = faces[18];
            newFaces[19] = faces[19];
            newFaces[20] = faces[3];
            newFaces[21] = faces[21];
            newFaces[22] = faces[1];
            newFaces[23] = faces[23];
        }
        else if (move=="R'"){
            newFaces[0] = faces[0];
            newFaces[1] = faces[22];
            newFaces[2] = faces[2];
            newFaces[3] = faces[20];
            newFaces[4] = faces[5];
            newFaces[5] = faces[7];
            newFaces[6] = faces[4];
            newFaces[7] = faces[6];
            newFaces[8] = faces[8];
            newFaces[9] = faces[1];
            newFaces[10] = faces[10];
            newFaces[11] = faces[3];
            newFaces[12] = faces[12];
            newFaces[13] = faces[9];
            newFaces[14] = faces[14];
            newFaces[15] = faces[11];
            newFaces[16] = faces[16];
            newFaces[17] = faces[17];
            newFaces[18] = faces[18];
            newFaces[19] = faces[19];
            newFaces[20] = faces[15];
            newFaces[21] = faces[21];
            newFaces[22] = faces[13];
            newFaces[23] = faces[23];
        }
        else if (move=="U"){
            newFaces[0] = faces[2];
            newFaces[1] = faces[0];
            newFaces[2] = faces[3];
            newFaces[3] = faces[1];
            newFaces[4] = faces[20];
            newFaces[5] = faces[21];
            newFaces[6] = faces[6];
            newFaces[7] = faces[7];
            newFaces[8] = faces[4];
            newFaces[9] = faces[5];
            newFaces[10] = faces[10];
            newFaces[11] = faces[11];
            newFaces[12] = faces[12];
            newFaces[13] = faces[13];
            newFaces[14] = faces[14];
            newFaces[15] = faces[15];
            newFaces[16] = faces[8];
            newFaces[17] = faces[9];
            newFaces[18] = faces[18];
            newFaces[19] = faces[19];
            newFaces[20] = faces[16];
            newFaces[21] = faces[17];
            newFaces[22] = faces[22];
            newFaces[23] = faces[23];
        }
        else if (move=="U'"){
            newFaces[0] = faces[1];
            newFaces[1] = faces[3];
            newFaces[2] = faces[0];
            newFaces[3] = faces[2];
            newFaces[4] = faces[8];
            newFaces[5] = faces[9];
            newFaces[6] = faces[6];
            newFaces[7] = faces[7];
            newFaces[8] = faces[16];
            newFaces[9] = faces[17];
            newFaces[10] = faces[10];
            newFaces[11] = faces[11];
            newFaces[12] = faces[12];
            newFaces[13] = faces[13];
            newFaces[14] = faces[14];
            newFaces[15] = faces[15];
            newFaces[16] = faces[20];
            newFaces[17] = faces[11];
            newFaces[18] = faces[18];
            newFaces[19] = faces[19];
            newFaces[20] = faces[4];
            newFaces[21] = faces[5];
            newFaces[22] = faces[22];
            newFaces[23] = faces[23];
        }
        else if (move=="B"){
            newFaces[0] = faces[5];
            newFaces[1] = faces[7];
            newFaces[2] = faces[2];
            newFaces[3] = faces[3];
            newFaces[4] = faces[4];
            newFaces[5] = faces[15];
            newFaces[6] = faces[6];
            newFaces[7] = faces[14];
            newFaces[8] = faces[8];
            newFaces[9] = faces[9];
            newFaces[10] = faces[10];
            newFaces[11] = faces[11];
            newFaces[12] = faces[12];
            newFaces[13] = faces[13];
            newFaces[14] = faces[16];
            newFaces[15] = faces[18];
            newFaces[16] = faces[1];
            newFaces[17] = faces[17];
            newFaces[18] = faces[0];
            newFaces[19] = faces[19];
            newFaces[20] = faces[22];
            newFaces[21] = faces[20];
            newFaces[22] = faces[23];
            newFaces[23] = faces[21];
        }
        else if (move=="B'"){
            newFaces[0] = faces[18];
            newFaces[1] = faces[16];
            newFaces[2] = faces[2];
            newFaces[3] = faces[3];
            newFaces[4] = faces[4];
            newFaces[5] = faces[0];
            newFaces[6] = faces[6];
            newFaces[7] = faces[1];
            newFaces[8] = faces[8];
            newFaces[9] = faces[9];
            newFaces[10] = faces[10];
            newFaces[11] = faces[11];
            newFaces[12] = faces[12];
            newFaces[13] = faces[13];
            newFaces[14] = faces[7];
            newFaces[15] = faces[5];
            newFaces[16] = faces[14];
            newFaces[17] = faces[17];
            newFaces[18] = faces[15];
            newFaces[19] = faces[19];
            newFaces[20] = faces[21];
            newFaces[21] = faces[23];
            newFaces[22] = faces[20];
            newFaces[23] = faces[22];
        }
        else if (move=="L"){
            newFaces[0] = faces[23];
            newFaces[1] = faces[1];
            newFaces[2] = faces[21];
            newFaces[3] = faces[3];
            newFaces[4] = faces[4];
            newFaces[5] = faces[5];
            newFaces[6] = faces[6];
            newFaces[7] = faces[7];
            newFaces[8] = faces[0];
            newFaces[9] = faces[9];
            newFaces[10] = faces[2];
            newFaces[11] = faces[11];
            newFaces[12] = faces[8];
            newFaces[13] = faces[13];
            newFaces[14] = faces[10];
            newFaces[15] = faces[15];
            newFaces[16] = faces[18];
            newFaces[17] = faces[16];
            newFaces[18] = faces[19];
            newFaces[19] = faces[17];
            newFaces[20] = faces[20];
            newFaces[21] = faces[14];
            newFaces[22] = faces[22];
            newFaces[23] = faces[12];
        }
        else if (move== "L'"){
            newFaces[0] = faces[8];
            newFaces[1] = faces[1];
            newFaces[2] = faces[10];
            newFaces[3] = faces[3];
            newFaces[4] = faces[4];
            newFaces[5] = faces[5];
            newFaces[6] = faces[6];
            newFaces[7] = faces[7];
            newFaces[8] = faces[12];
            newFaces[9] = faces[9];
            newFaces[10] = faces[14];
            newFaces[11] = faces[11];
            newFaces[12] = faces[23];
            newFaces[13] = faces[13];
            newFaces[14] = faces[21];
            newFaces[15] = faces[15];
            newFaces[16] = faces[17];
            newFaces[17] = faces[19];
            newFaces[18] = faces[16];
            newFaces[19] = faces[18];
            newFaces[20] = faces[20];
            newFaces[21] = faces[2];
            newFaces[22] = faces[22];
            newFaces[23] = faces[0];
        }
        else if (move=="D"){
            newFaces[0] = faces[0];
            newFaces[1] = faces[1];
            newFaces[2] = faces[2];
            newFaces[3] = faces[3];
            newFaces[4] = faces[4];
            newFaces[5] = faces[5];
            newFaces[6] = faces[10];
            newFaces[7] = faces[11];
            newFaces[8] = faces[8];
            newFaces[9] = faces[9];
            newFaces[10] = faces[18];
            newFaces[11] = faces[19];
            newFaces[12] = faces[14];
            newFaces[13] = faces[12];
            newFaces[14] = faces[15];
            newFaces[15] = faces[13];
            newFaces[16] = faces[16];
            newFaces[17] = faces[17];
            newFaces[18] = faces[22];
            newFaces[19] = faces[23];
            newFaces[20] = faces[20];
            newFaces[21] = faces[21];
            newFaces[22] = faces[6];
            newFaces[23] = faces[7];

        }
        else if (move=="D'"){
            newFaces[0] = faces[0];
            newFaces[1] = faces[1];
            newFaces[2] = faces[2];
            newFaces[3] = faces[3];
            newFaces[4] = faces[4];
            newFaces[5] = faces[5];
            newFaces[6] = faces[22];
            newFaces[7] = faces[23];
            newFaces[8] = faces[8];
            newFaces[9] = faces[9];
            newFaces[10] = faces[6];
            newFaces[11] = faces[7];
            newFaces[12] = faces[12];
            newFaces[13] = faces[15];
            newFaces[14] = faces[12];
            newFaces[15] = faces[14];
            newFaces[16] = faces[16];
            newFaces[17] = faces[17];
            newFaces[18] = faces[10];
            newFaces[19] = faces[11];
            newFaces[20] = faces[20];
            newFaces[21] = faces[21];
            newFaces[22] = faces[18];
            newFaces[23] = faces[19];
        }

        List<String[]> pathToState = new ArrayList<>();
        String[] m = move.split("");
        pathToState.addAll(state.path);
        pathToState.add(m);
        
        
        State newState = new State(newFaces,pathToState);
                
        return newState;
    }
}
