
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Solver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        
    	List<String[]> dr = new ArrayList<String[]>();

        String userInput = scanner.nextLine();
        
    	String[] input = new String[24];

        
        for(int i=0; i<=23; i++)
        {
        	input[i] = userInput.substring(i, i+1);
        }
        
        State s = new State(input , dr);
      
        
        System.out.print("Enter a search: 'DFS' OR 'ASTAR' OR 'UCS':");
        String userFunc = scanner.nextLine();
        
        if(userFunc.equals("DFS") || userFunc.equals("dfs"))
        {
        	DFS.dfs(s,15);
        }
        if(userFunc.equals("ASTAR") || userFunc.equals("astar") || userFunc.equals("Astar"))
        {
        	Astar.aStarSearch(s);
        }
        if(userFunc.equals("UCS") || userFunc.equals("ucs"))
        {
        	Astar.uniformCostSearch(s);
        }
}
	
}
