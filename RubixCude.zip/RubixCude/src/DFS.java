import java.util.ArrayList;
import java.util.List;

public class DFS {
	
	private static int visitedStates = 0;
	public static boolean dfs(State currentState, int depthLimit) {
		
    	visitedStates++;

        if (currentState.isGoal()) {
        	
        	System.out.print("[");
        	 for (String[] array : currentState.path) {
        	        for (String str : array) {
        	            System.out.print(str + " ");
        	        }
        	 }
         	System.out.print("]");
        	 System.out.println();
        	 
            System.out.println("Cube solved!");
        	System.out.println("State visited:" + visitedStates);

            return true;
        }
        

        if (depthLimit <= 0) {
            return false;
        }

        List<State> possibleMoves = State.successorFunction(currentState);

        
        for (State move : possibleMoves) {
        	
            if (dfs(move, depthLimit - 1)) {

                return true;
            }
       }
        return false;
    }

}
