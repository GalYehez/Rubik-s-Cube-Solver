import java.util.ArrayList;
import java.util.List;

public class State {
	
	public String[] numbers = new String[23];
	
	public List<String[]> path = new ArrayList<String[]>();
	
	public int hCost = 0;
	
	public int gCost = 0;
	
	public int fCost =0;
	
     public State(String[] numbers, List<String[]> p)
 	{
 		this.numbers=numbers;
 		this.path=p;
 		
		this.gCost = this.path.size();
 		this.hCost = Astar.heuristic(this);
		this.fCost = gCost + hCost;
 	}
	
	
	public boolean isGoal()
	{
		int j=0;
		for(int i=0; i<=5; i++)
		{
			for(int k=0; k<3; k++)
			{
				if(!(this.numbers[j].equals(numbers[j+1])))
				{
					return false;
				}
				j++;
			}
			j++;
		}
		return true;
	}
	
	public static List<State> successorFunction(State s)
	{
  
		List<State> successor = new ArrayList<State>();
		
		successor.add(Moves.applyMove(s, "D"));
		successor.add(Moves.applyMove(s, "U"));
		successor.add(Moves.applyMove(s, "U'"));
		successor.add(Moves.applyMove(s, "B"));
		successor.add(Moves.applyMove(s, "R"));
		successor.add(Moves.applyMove(s, "L"));
		successor.add(Moves.applyMove(s, "F"));
		successor.add(Moves.applyMove(s, "F'"));
		successor.add(Moves.applyMove(s, "B'"));
		successor.add(Moves.applyMove(s, "R'"));
		successor.add(Moves.applyMove(s, "L'"));
		successor.add(Moves.applyMove(s, "D'"));

        return successor;
	}
	
}


