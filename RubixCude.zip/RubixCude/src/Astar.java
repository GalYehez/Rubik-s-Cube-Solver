import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;

public class Astar {

	//The heuristic that sums all the squares in each wig that are out of place,
	//together to the first wig on the left. The color in the first square on the left is 
	//the color that is "set" for the wig and for every square that is not in the same color
	//the counter increases by one and adds up to the heuristic until the goal state.
	public static int heuristic(State state) {
	    int count = 0;
	    for (int i = 0; i < state.numbers.length; i += 4) {
	        for (int j = 0; j < 4; j++) {
	            if (!state.numbers[i + j].equals(state.numbers[i])) {
	                count++;
	            }
	        }
	    }
	    return count;
	}
	
		public static boolean aStarSearch(State initialState) {
			int visitedStates = 0;
		    // Initialize the priority queue with a comparator based on depth + heuristic value
			
		    PriorityQueue<State> openSet = new PriorityQueue<>(
		            Comparator.comparingInt(s -> s.path.size() + heuristic(s))
		    );

		    // Add the initial state to the open set
		    initialState.path.clear();
		  int size= initialState.path.size();
		  initialState.gCost=size;
		   int h = heuristic(initialState);
		   initialState.hCost=h;
		    //adding the first element to the Priority Queue
		    openSet.add(initialState);

		    // Map to store the lowest cost to a state (using the state's faces as key)
		    Map<String, Integer> costSoFar = new HashMap<>();
		    costSoFar.put(Arrays.toString(initialState.numbers), 0);

		    while (!openSet.isEmpty()) {
		        State currentState = openSet.poll();

		        // Check if the current state is the goal state
		        if (currentState.isGoal()) {
		        	
		        	System.out.print("[");
		        	 for (String[] array : currentState.path) {
		        	        for (String str : array) {
		        	            System.out.print(str + " ");
		        	        }
		        	 }
		         	System.out.print("]");
		        	 System.out.println();
		        	System.out.println("Cube solved!");
	            	System.out.println("State visited:" + visitedStates);

		        	
		        	return true;
		        }

		        // Iterate through all successors of the current state
		        for (State nextState : State.successorFunction(currentState)) {
		            int newCost = currentState.path.size() + 1; // Cost to reach this successor

		            String nextStateKey = Arrays.toString(nextState.numbers);
		            if (!costSoFar.containsKey(nextStateKey) || newCost < costSoFar.get(nextStateKey)) {
		                // Update the cost for this state
		                costSoFar.put(nextStateKey, newCost);

		                nextState.gCost=newCost;
		             //   nextState.computeHeuristicValue();
		                nextState.hCost= heuristic(nextState);

		                openSet.add(nextState);
		                visitedStates++;
		            }
		        }
		    }

		    return false;
		}
		
		public static boolean uniformCostSearch(State initialState) {
			 int visitedStates =0;
	        PriorityQueue<State> openSet = new PriorityQueue<>(Comparator.<State>comparingInt(s -> s.gCost)
	        		.thenComparing(s -> Arrays.toString(s.numbers)));

	        openSet.add(initialState);
	        Map<String, Integer> costSoFar = new HashMap<>();
	        costSoFar.put(Arrays.toString(initialState.numbers), 0);

	        while (!openSet.isEmpty()) {
	            State currentState = openSet.poll();

	            if (currentState.isGoal()) {
	                // Reconstruct the path from the goal state to the initial state
	            	System.out.println("Cube solved!!!");
	            	System.out.println("State visited:" + visitedStates);
	            	
	            	System.out.print("[");
	            	 for (String[] array : currentState.path) {
	            	        for (String str : array) {
	            	            System.out.print(str + " ");
	            	        }
	            	 }
	             	System.out.print("]");
	            	 System.out.println();
	              
	                return true;
	            }

	            for (State nextState : State.successorFunction(currentState)) {
	                int newCost = currentState.path.size() + 1;
	                String nextStateKey = Arrays.toString(nextState.numbers);
	                if (!costSoFar.containsKey(nextStateKey) || newCost < costSoFar.get(nextStateKey)) {
	                    costSoFar.put(nextStateKey, newCost);
	                    nextState.gCost=newCost;
	                    openSet.add(nextState);
	        
	                    visitedStates++;
	                }
	            }
	        }
	        
	        return false;
	    }
		
}
